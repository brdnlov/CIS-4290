<?php
// All files that need to be included by all the CIS 4270 applications.
// @author jam
// @version 180426

//include_once(NON_WEB_BASE_DIR .'common/db/DBAccess.php');
include_once(NON_WEB_BASE_DIR .'common/db/DBAccessAchtung.php');
include_once(NON_WEB_BASE_DIR .'common/db/DAM.php');
include_once(NON_WEB_BASE_DIR .'common/includes/sanitizationFunctions.php');
include_once(NON_WEB_BASE_DIR .'common/includes/validationFunctions.php');
include_once(NON_WEB_BASE_DIR .'common/includes/sessionFunctions.php');
include_once(NON_WEB_BASE_DIR .'common/includes/csrf_request_type_functions.php');
include_once(NON_WEB_BASE_DIR .'common/includes/csrf_token_functions.php');



