<?php
// All files that need to be included by all the dbSecure application
// assignments.
// @author jam
// @version 180426

// Includes common to other cis 4270 applications
include_once(NON_WEB_BASE_DIR . 'common/includes/cis4270CommonIncludes.php');

// Includes specific to this application.
include_once(APP_NON_WEB_BASE_DIR .'includes/deployment.php');



