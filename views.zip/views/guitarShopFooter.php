<footer>
    <p id="copyright">
        &copy; <?php echo date("Y"); ?> guitarShop, Inc.
    </p>
</footer>
</body>
</html>
