<!DOCTYPE html>
<!--[if lt IE 7]><html class="no-js lt-ie10 lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]><html class="no-js lt-ie10 lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]><html class="no-js lt-ie10 lt-ie9"> <![endif]-->
<!--[if IE 9]><html class="no-js lt-ie10"> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js">
<!--<![endif]-->

<head>
	<!-- Basic Page Needs -->
	<meta charset="utf-8">
	<title>Be</title>
	<meta name="description" content="">
	<meta name="author" content="">
	<!-- Mobile Specific Metas -->
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<!-- Favicons -->
	<link rel="shortcut icon" href="content/dietshop/images/favicon.ico">
	<!-- FONTS -->
	<link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Nunito+Sans:100,200,300,400,400italic,500,600,700,700italic,900'>
	<link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Nunito:100,200,300,400,400italic,500,600,700,700italic,900'>
	<link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Montserrat:100,200,300,400,400italic,500,600,700,700italic,900'>
	<!-- Bootstrap core CSS -->
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<!--CSS -->
	<link rel='stylesheet' href='content/dietshop/css/structure.css'>
	<link rel='stylesheet' href='content/dietshop/css/dietshop.css'>
	<!-- Revolution Slider -->
	<link rel="stylesheet" href="plugins/rs-plugin-6.custom/css/rs6.css"> </head>

<body class="home page theme-betheme woocommerce-no-js template-slider content-brightness-light input-brightness-light style-default button-custom layout-full-width if-zoom no-shadows header-classic sticky-header sticky-tb-color ab-show subheader-both-center menu-link-color menuo-no-borders logo-no-margin mobile-tb-center mobile-side-slide mobile-mini-mr-lc mobile-sticky mobile-header-mini mobile-icon-user-ss mobile-icon-wishlist-ss mobile-icon-search-ss mobile-icon-wpml-ss mobile-icon-action-ss be-page-19 be-reg-2513 wishlist-active wishlist-button mobile-row-2-products mfn-variable-swatches product-zoom-disabled mfn-ajax-add-to-cart">
	<div id="Wrapper">
		<div id="Header_wrapper">
			<header id="Header">
				<div id="Action_bar">
					<div class="container">
						<div class="column one">
							<ul class="contact_details">
								<li class="slogan"> <b>HOT DISCOUT ENDS 15th JULY - FIND OUT MORE</b> </li>
							</ul>
						</div>
					</div>
				</div>
				<div id="Top_bar">
					<div class="container">
						<div class="column one">
							<div class="top_bar_left clearfix">
								<div class="logo">
									<a id="logo" href="." title="BeDietShop - Betheme" data-height="60" data-padding="15"><img class="logo-main scale-with-grid" src="content/dietshop/images/dietshop.webp" data-retina="content/dietshop/images/retina-dietshop-1.webp" data-height="40" alt="dietshop" /><img class="logo-sticky scale-with-grid" src="content/dietshop/images/dietshop.webp" data-retina="content/dietshop/images/retina-dietshop-1.webp" data-height="40" alt="dietshop" /><img class="logo-mobile scale-with-grid" src="content/dietshop/images/dietshop.webp" data-retina="content/dietshop/images/retina-dietshop-1.webp" data-height="40" alt="dietshop" /><img class="logo-mobile-sticky scale-with-grid" src="content/dietshop/images/dietshop.webp" data-retina="content/dietshop/images/retina-dietshop-1.webp" data-height="40" alt="dietshop" /></a>
								</div>
							</div>
							<div class="top_bar_right">
								<div class="top_bar_right_wrapper">
									<div class="menu_wrapper">
										<nav id="menu">
												<ul id="menu-main-menu" class="menu menu-main">
												<li class="current-menu-item"> <a href="."><span>Home</span></a> </li>
												<li> <a href="?ctlr=home&amp;action=shop"><span>Shop</span></a> </li>												
												<li> <a href="?ctlr=admin&amp;action=blog"><span>Blog</span></a> </li>
												<?php if (!isset($_SESSION ['userId'])) {    echo "
												<li> <a href='?ctlr=admin&amp;action=login'><span>Login</span></a> </li>";
												echo "<li> <a href='?ctlr=admin&amp;action=register'><span>Register</span></a> </li>";												}?>

												
												<?php if (isset($_SESSION ['userId'])) {    
												echo "<li> <a href='?ctlr=admin&amp;action=addProduct'><span>Add Review</span></a> </li>";
												echo "
												<li>
													<a href='?ctlr=admin&amp;action=addReview'><span>User: "; echo $_SESSION ['userId']; echo "</span></a>
												
													
												</li>";
													}?>
												<?php if (isset($_SESSION ['userId'])) {

												echo "<li>
													<a href='?ctlr=admin&amp;action=logout'><span>Logout</span></a></li>";
													
												}?>
												
											</ul>
										</nav><a class="responsive-menu-toggle" href="#" aria-label="Mobile menu"><i class="icon-menu-fine" aria-hidden="true"></i></a> </div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="mfn-main-slider mfn-rev-slider">
					<!-- START Home Dietshop REVOLUTION SLIDER 6.5.8 -->
					<p class="rs-p-wp-fix"></p>
					<rs-module-wrap id="rev_slider_1_1_wrapper" data-source="gallery" style="visibility:hidden;background:transparent;padding:0;margin:0px auto;margin-top:0;margin-bottom:0;">
						<rs-module id="rev_slider_1_1" data-version="6.5.8">
							<rs-slides>
								<rs-slide style="position: absolute;" data-key="rs-1" data-title="Slide" data-anim="ms:1000ms;" data-in="o:0;" data-out="a:false;"> <img src="content/dietshop/images/dummy.png" alt="Slide" title="Home" class="rev-slidebg tp-rs-img rs-lazyload" data-lazyload="content/dietshop/images/transparent.png">
									<!--
										-->
									<rs-layer id="slider-1-slide-1-layer-0" data-type="shape" data-rsp_ch="on" data-xy="x:r,r,c,c;" data-text="w:normal;s:20,20,11,11;l:0,0,14,14;" data-dim="w:50%,50%,100%,100%;h:100%,100%,50%,50%;" data-basealign="slide" data-frame_1="e:power4.inOut;sp:1000;" data-frame_999="o:0;st:w;" style="z-index:9;background-color:rgba(0,0,0,0.5);">
										<rs-bg-elem style="background: url('content/dietshop/images/dietshop-slider-pic1.webp') no-repeat center center; background-size: cover;"></rs-bg-elem>
									</rs-layer>
									<!--
										-->
								</rs-slide>
								<rs-slide style="position: absolute;" data-key="rs-2" data-title="Slide" data-anim="ms:100ms;" data-in="o:0;" data-out="a:false;"> <img src="content/dietshop/images/dummy.png" alt="Slide" title="Home" class="rev-slidebg tp-rs-img rs-lazyload" data-lazyload="content/dietshop/images/transparent.png">
									<!--
										-->
									<rs-layer id="slider-1-slide-2-layer-0" data-type="shape" data-rsp_ch="on" data-xy="x:r,r,c,c;" data-text="w:normal;s:20,20,11,11;l:0,0,14,14;" data-dim="w:50%,50%,100%,100%;h:100%,100%,50%,50%;" data-basealign="slide" data-frame_1="e:power4.inOut;sp:1000;" data-frame_999="o:0;st:w;" style="z-index:9;background-color:rgba(0,0,0,0.5);">
										<rs-bg-elem style="background: url('content/dietshop/images/dietshop-slider-pic2.webp') no-repeat center center; background-size: cover;"></rs-bg-elem>
									</rs-layer>
									<!--
										-->
								</rs-slide>
								<rs-slide style="position: absolute;" data-key="rs-3" data-title="Slide" data-anim="ms:100ms;" data-in="o:0;" data-out="a:false;"> <img src="content/dietshop/images/dummy.png" alt="Slide" title="Home" class="rev-slidebg tp-rs-img rs-lazyload" data-lazyload="content/dietshop/images/transparent.png">
									<!--
										-->
									<rs-layer id="slider-1-slide-3-layer-0" data-type="shape" data-rsp_ch="on" data-xy="x:r,r,c,c;" data-text="w:normal;s:20,20,11,11;l:0,0,14,14;" data-dim="w:50%,50%,100%,100%;h:100%,100%,50%,50%;" data-basealign="slide" data-frame_1="e:power4.inOut;sp:1000;" data-frame_999="o:0;st:w;" style="z-index:9;background-color:rgba(0,0,0,0.5);">
										<rs-bg-elem style="background: url('content/dietshop/images/dietshop-slider-pic3.webp') no-repeat center center; background-size: cover;"></rs-bg-elem>
									</rs-layer>
									<!--
										-->
								</rs-slide>
							</rs-slides>
							<rs-static-layers>
								<!--

									-->
								<rs-layer id="slider-1-slide-1-layer-1" class="rs-layer-static" data-type="text" data-color="#f2654a" data-rsp_ch="on" data-xy="x:l,l,c,c;xo:81px,81px,0,81px;y:t,t,m,m;yo:150px,150px,180px,180px;" data-text="w:normal;s:50;l:65;fw:800;a:left,left,center,center;" data-dim="w:450px,450px,500px,500px;" data-onslides="s:1;" data-frame_0="y:-50,-50,-28,-28;" data-frame_1="sp:1000;" data-frame_999="o:0;st:w;" style="z-index:10;font-family:'Nunito Sans';"> Your diet can
									<br/> be tasty & healthy. Effortlessly... </rs-layer>
								<!--

									-->
								<rs-layer id="slider-1-slide-1-layer-2" class="rs-layer-static" data-type="image" data-rsp_ch="on" data-xy="x:l,l,c,c;xo:136px,136px,-82px,-82px;y:t,t,m,m;yo:213px,213px,188px,188px;" data-text="w:normal;s:20,20,11,11;l:0,0,14,14;" data-dim="w:['168px','168px','168px','168px'];h:['72px','72px','72px','72px'];" data-onslides="s:1;" data-frame_0="y:-50,-50,-28,-28;" data-frame_1="sp:1000;" data-frame_999="o:0;st:w;" style="z-index:9;"><img src="content/dietshop/images/dummy.png" class="tp-rs-img rs-lazyload" width="168" height="72" data-lazyload="content/dietshop/images/dietshop-slider-pic4.webp"> </rs-layer>
								<!--

									-->
								<rs-layer id="slider-1-slide-1-layer-3" class="rs-layer-static" data-type="image" data-rsp_ch="on" data-xy="x:l,l,c,c;xo:407px,407px,191px,191px;y:t,t,m,m;yo:278px,278px,240px,240px;" data-text="w:normal;s:20,20,11,11;l:0,0,14,14;" data-dim="w:56px,56px,60px,60px;h:56px,56px,60px,60px;" data-onslides="s:1;" data-frame_0="y:-50,-50,-28,-28;" data-frame_1="sp:1000;" data-frame_999="o:0;st:w;" style="z-index:11;"><img src="content/dietshop/images/dummy.png" class="tp-rs-img rs-lazyload" width="56" height="56" data-lazyload="content/dietshop/images/dietshop-icon1.webp"> </rs-layer>
								<!--

									--><a id="slider-1-slide-1-layer-4" class="rs-layer rev-btn rs-layer-static" href="content/dietshop/blog.html" target="_self" data-type="button" data-color="#f1ffba" data-rsp_ch="on" data-xy="x:l,l,c,c;xo:80px,80px,-6px,-6px;y:t,t,m,m;yo:400px,400px,355px,355px;" data-text="w:normal;s:20,20,30,30;l:32,32,40,40;fw:700;" data-dim="minh:0px,0px,none,0px;" data-onslides="s:1;" data-padding="t:12,12,7,7;r:50,50,29,29;b:12,12,7,7;l:50,50,29,29;" data-border="bor:29px,29px,29px,29px;" data-frame_0="y:50,50,28,28;" data-frame_1="sp:1000;" data-frame_999="o:0;st:w;" data-frame_hover="c:#fff;bgc:#8eb747;bor:29px,29px,29px,29px;" style="z-index:12;background-color:#75973a;font-family:'Nunito';">View diets </a>
								<!--

									-->
								<rs-layer id="slider-1-slide-1-layer-5" class="rs-layer-static" data-type="text" data-color="#6e2a36" data-rsp_ch="on" data-xy="xo:81px,81px,52px,52px;yo:480px,480px,723px,723px;" data-text="w:normal;s:17,17,9,9;l:25,25,14,14;" data-vbility="t,t,f,t" data-onslides="s:1;" data-frame_0="y:50,50,28,28;" data-frame_1="x:2px,2px,0px,0px;sp:1000;" data-frame_999="o:0;st:w;" style="z-index:13;font-family:'Nunito Sans';"> All diet’s are gluten free </rs-layer>
								<!--

									-->
								<rs-layer id="slider-1-slide-1-layer-6" class="rs-layer-static" data-type="image" data-rsp_ch="on" data-xy="x:r,r,c,c;xo:-40px,-40px,270px,270px;y:b,b,t,b;yo:-40px;" data-text="w:normal;s:20,20,11,11;l:0,0,14,14;" data-dim="w:368px,368px,300px,300px;h:368px,368px,300px,300px;" data-basealign="slide" data-onslides="s:1;" data-frame_0="oZ:0px;" data-frame_1="oZ:0px;sp:1000;" data-frame_999="o:0;st:w;" data-loop_999="rZ:-360deg;sp:15000;st:0;" style="z-index:14;"><img src="content/dietshop/images/dummy.png" class="tp-rs-img rs-lazyload" width="368" height="368" data-lazyload="content/dietshop/images/dietshop-slider-pic5-1.webp"> </rs-layer>
								<!--

									-->
							</rs-static-layers>
						</rs-module>
					</rs-module-wrap>
					<!-- END REVOLUTION SLIDER -->
				</div>
			</header>
		</div>
		<div id="Content">
			<div class="section mcb-section" style="padding-top:40px;background-color:#f4e0c9">
				<div class="container">
					<div class="row" data-col="one">
						<div class="col-12 text-center column-margin-30px">
							<h5>Quantum pertore <span style="color: #6e2a36;">di allen</span> quento</h5>
							<hr class="no_line" style="margin:0 auto 40px"> </div>
					</div>
				</div>
				<div class="section-divider triangle down"></div>
			</div>
			<div class="section mcb-section" style="padding-top:100px;padding-bottom:60px">
				<div class="container">
					<div class="row" data-col="one">
						<div class="col-12 column_shop_slider">
							<div class="shop_slider" data-count="3">
								<div class="blog_slider_header clearfix">
									<h4 class="title">Chef’s special meals</h4>
									<div class="slider_navigation"></div>
								</div>
								<ul class="shop_slider_ul">
									<li class="product type-product has-post-thumbnail product_cat-brunch product_cat-fruits product_cat-gluten-free product_tag-brunch product_tag-meat first instock sale shipping-taxable purchasable product-type-variable has-default-attributes">
										<div class="item_wrapper">
											<div class="image_frame scale-with-grid product-loop-thumb">
												<div class="image_wrapper"> <span class="onsale onsale-label">-30%</span>
													<a href="content/dietshop/product.html">
														<div class="mask"></div><img width="500" height="500" src="content/dietshop/images/dietshop-product-pic1-500x500.webp" class="scale-with-grid wp-post-image" loading="lazy" /></a>
												</div>
											</div>
											<div class="desc">
												<h4><a href="content/dietshop/product.html">Brunch low-carb box</a></h4><span class="price"><span class="woocommerce-Price-amount amount">
																				<bdi>
																					<span class="woocommerce-Price-currencySymbol">&#36;</span>14.00 </bdi>
												</span> &ndash; <span class="woocommerce-Price-amount amount">
																				<bdi>
																					<span class="woocommerce-Price-currencySymbol">&#36;</span>28.00 </bdi>
												</span>
												</span>
											</div>
										</div>
									</li>
									<li class="product type-product has-post-thumbnail product_cat-fruits-and-additions product_cat-gluten-free product_cat-lunch product_tag-lunch product_tag-vegan instock sale shipping-taxable purchasable product-type-variable has-default-attributes">
										<div class="item_wrapper">
											<div class="image_frame scale-with-grid product-loop-thumb">
												<div class="image_wrapper"> <span class="onsale onsale-label">-29%</span>
													<a href="content/dietshop/product.html">
														<div class="mask"></div><img width="500" height="500" src="content/dietshop/images/dietshop-product-pic2-500x500.webp" class="scale-with-grid wp-post-image" loading="lazy" /></a>
												</div>
											</div>
											<div class="desc">
												<h4><a href="content/dietshop/product.html">Lunch vegan box</a></h4><span class="price"><span class="woocommerce-Price-amount amount">
																				<bdi>
																					<span class="woocommerce-Price-currencySymbol">&#36;</span>13.00 </bdi>
												</span> &ndash; <span class="woocommerce-Price-amount amount">
																				<bdi>
																					<span class="woocommerce-Price-currencySymbol">&#36;</span>22.00 </bdi>
												</span>
												</span>
											</div>
										</div>
									</li>
									<li class="product type-product has-post-thumbnail product_cat-dinner product_cat-gluten-free product_cat-meal product_tag-dinner product_tag-paleo last instock sale shipping-taxable purchasable product-type-variable has-default-attributes">
										<div class="item_wrapper">
											<div class="image_frame scale-with-grid product-loop-thumb">
												<div class="image_wrapper"> <span class="onsale onsale-label">-13%</span>
													<a href="content/dietshop/product.html">
														<div class="mask"></div><img width="500" height="500" src="content/dietshop/images/dietshop-product-pic3-500x500.webp" class="scale-with-grid wp-post-image" loading="lazy" /></a>
												</div>
											</div>
											<div class="desc">
												<h4><a href="content/dietshop/product.html">Dinner paleo box</a></h4><span class="price"><span class="woocommerce-Price-amount amount">
																				<bdi>
																					<span class="woocommerce-Price-currencySymbol">&#36;</span>13.00 </bdi>
												</span> &ndash; <span class="woocommerce-Price-amount amount">
																				<bdi>
																					<span class="woocommerce-Price-currencySymbol">&#36;</span>22.00 </bdi>
												</span>
												</span>
											</div>
										</div>
									</li>
								</ul>
								<div class="slider_pager slider_pagination"></div>
							</div>
						</div>
						<div class="col-12">
							<hr class="no_line" style="margin: 0 auto 80px auto" /> </div>
						<div class="col-md-2">
							<div class="placeholder"> &nbsp; </div>
						</div>
						<div class="col-md-6">
							<h4 style="font-weight:400;">Browse and choose from all our meals</h4> </div>
						<div class="colcol-md-3"> <a class="button button_size_2" href="content/dietshop/shop.html"><span class="button_label">See all meals</span></a> </div>
						<div class="col-12">
							<hr class="no_line" style="margin: 0 auto 50px auto" /> </div>
						<div class="col-12">
							<hr style="margin:0 auto 100px;background-color:#eed7b9" /> </div>
						<div class="col-md-3">
							<div class="placeholder"> &nbsp; </div>
						</div>
						<div class="col-md-7">
							<div class="text-center">
								<h2>Our services are top quality <span style="color: #6e2a36;">and we're doing our best for your happiness and health</span><img class="scale-with-grid" src="content/dietshop/images/dietshop-icon3.webp"/></h2> </div>
						</div>
						<div class="col-12">
							<hr class="no_line" style="margin: 0 auto 20px auto" /> </div>
						<div class="col-md-4">
							<div class="column_attr clearfix mobile_align_center" style="padding:0 4%;"><img class="scale-with-grid" src="content/dietshop/images/dietshop-home-pic1.webp" />
								<hr class="no_line" style="margin: 0 auto 40px auto" />
								<h5>1. <span style="color: #6e2a36;">Select a diet that suits your needs</span></h5>
								<p> Duis aute irure dolor in reprehenderit in voluptate velit esse cillum ecat. </p>
							</div>
						</div>
						<div class="col-md-4">
							<div class="column_attr clearfix mobile_align_center" style="padding:0 4%;"><img class="scale-with-grid" src="content/dietshop/images/dietshop-home-pic2.webp" />
								<hr class="no_line" style="margin: 0 auto 40px auto" />
								<h5>2. <span style="color: #6e2a36;">Order your meals regularly</span></h5>
								<p> Voluptate velit esse cillum dolore eu fugiat nulla pariatur. Exce pteur occaecat. </p>
							</div>
						</div>
						<div class="col-md-4">
							<div class="column_attr clearfix mobile_align_center" style="padding:0 4%;"><img class="scale-with-grid" src="content/dietshop/images/dietshop-home-pic3.webp" />
								<hr class="no_line" style="margin: 0 auto 40px auto" />
								<h5>3. <span style="color: #6e2a36;">Enjoy good and healthy life </span><img class="scale-with-grid" src="content/dietshop/images/dietshop-icon4.webp"/></h5>
								<p> Aliqua. Ut enim ad minim veniam, quis exercitation ullaais. </p>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="section mcb-section no-margin-h no-margin-v equal-height" style="padding-bottom:100px;background-image:url(content/dietshop/images/dietshop-section-bg1.webp);background-repeat:repeat-x;background-position:center bottom">
				<div class="container">
					<div class="row no-gutters" data-col="one" style=";border-radius: 20px; overflow: hidden;">
						<div class="col-md-6">
							<div class="column_attr clearfix bg-cover" style="background-image:url('content/dietshop/images/dietshop-home-pic4.webp');background-repeat:no-repeat;background-position:center;">
								<hr class="no_line" style="margin: 0 auto 575px auto" /> </div>
						</div>
						<div class="col-md-6">
							<div class="column_attr clearfix mobile_align_center" style="background-color:#f2634d;padding:150px 8%;">
								<h2 style="color:#fffbf3;">Our all dishes are both Delicious and Healthy <img class="scale-with-grid" src="content/dietshop/images/dietshop-icon5.webp"/></h2>
								<p style="color:#fffbf3;"> Voluptate velit esse cillum dolore eu fugiat nulla pariatur. Exce pteur sint occaecat cupidatat non proident, sunt in culpa qui quantum. </p> <img class="scale-with-grid" style="margin: 0 30px 15px 0;" src="content/dietshop/images/dietshop-home-pic5.webp" /><a class="button button_size_2" href="content/dietshop/about.html" style="background-color:#6e2a36!important;color:#ffd4e8;"><span class="button_label">About us</span></a> </div>
						</div>
					</div>
				</div>
			</div>
			<div class="section mcb-section" style="padding-bottom:60px;background-color:#f6e9d6">
				<div class="container">
					<div class="row">
						<div class="col-12" data-col="one">
							<div class="text-center">
								<h2><span style="color: #6e2a36;">Read our</span> recipes, and healthy life ideas</h2>
								<hr class="no_line" style="margin:0 auto 50px"> </div>
							<div class="column_blog">
								<div class="column_filters">
									<div class="blog_wrapper isotope_wrapper clearfix">
										<div class="posts_group lm_wrapper col3 row photo2">
											<div class="col-md-4 post-item isotope-item clearfix post format-standard has-post-thumbnail">
												<div class="date_label"> October 4, 2021 </div>
												<div class="button-love"> <a href="#" class="mfn-love" data-id="116"><span class="icons-wrapper"><i class="icon-heart-empty-fa"></i><i class="icon-heart-fa"></i></span><span class="label">97</span></a> </div>
												<div class="image_frame post-photo-wrapper scale-with-grid images_only">
													<div class="image_wrapper">
														<a href="content/dietshop/post.html">
															<div class="mask"></div><img width="1200" height="675" src="content/dietshop/images/dietshop-blog-pic1-1200x675.webp" class="scale-with-grid wp-post-image" loading="lazy" /></a>
													</div>
												</div>
												<div class="post-desc-wrapper bg- has-custom-bg">
													<div class="post-desc">
														<div class="post-head"></div>
														<div class="post-title">
															<h4 class="entry-title"><a href="content/dietshop/post.html">Suspendisse eget leo ac turpis egestas. Suspendisse justo augue</a></h4> </div>
													</div>
												</div>
											</div>
											<div class="col-md-4 post-item isotope-item clearfix post format-standard has-post-thumbnail">
												<div class="date_label"> October 4, 2021 </div>
												<div class="button-love"> <a href="#" class="mfn-love" data-id="114"><span class="icons-wrapper"><i class="icon-heart-empty-fa"></i><i class="icon-heart-fa"></i></span><span class="label">80</span></a> </div>
												<div class="image_frame post-photo-wrapper scale-with-grid images_only">
													<div class="image_wrapper">
														<a href="content/dietshop/post.html">
															<div class="mask"></div><img width="1200" height="675" src="content/dietshop/images/dietshop-blog-pic2-1200x675.webp" class="scale-with-grid wp-post-image" loading="lazy" /></a>
													</div>
												</div>
												<div class="post-desc-wrapper bg- has-custom-bg">
													<div class="post-desc">
														<div class="post-head"></div>
														<div class="post-title">
															<h4 class="entry-title"><a href="content/dietshop/post.html">Etiam semper, quam nibh ut aliquet feugiat dui, porta sit amet erat</a></h4> </div>
													</div>
												</div>
											</div>
											<div class="col-md-4 post-item isotope-item clearfix post format-standard has-post-thumbnail">
												<div class="date_label"> October 4, 2021 </div>
												<div class="button-love"> <a href="#" class="mfn-love" data-id="112"><span class="icons-wrapper"><i class="icon-heart-empty-fa"></i><i class="icon-heart-fa"></i></span><span class="label">64</span></a> </div>
												<div class="image_frame post-photo-wrapper scale-with-grid images_only">
													<div class="image_wrapper">
														<a href="content/dietshop/post.html">
															<div class="mask"></div><img width="1200" height="675" src="content/dietshop/images/dietshop-blog-pic4-1200x675.webp" class="scale-with-grid wp-post-image" loading="lazy" /></a>
													</div>
												</div>
												<div class="post-desc-wrapper bg- has-custom-bg">
													<div class="post-desc">
														<div class="post-head"></div>
														<div class="post-title">
															<h4 class="entry-title"><a href="content/dietshop/post.html">Aenean congue ac, vulputate tempus ipsum. Nam dictum sit amet, nibh</a></h4> </div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="col-12" data-col="one">
							<div class="row">
								<div class="col-12">
									<hr class="no_line" style="margin: 0 auto 50px auto" /> </div>
								<div class="col-md-2 column_placeholder">
									<div class="placeholder"> &nbsp; </div>
								</div>
								<div class="col-md-6 text-center">
									<div class="column_attr clearfix mobile_align_center">
										<h4 style="font-weight:400; padding-top: 6px;">Browse and choose from all our meals</h4> </div>
								</div>
								<div class="col-md-3 column_button">
									<div class="button_align align_center"> <a class="button button_size_2" href="content/dietshop/shop.html"><span class="button_label">See all meals</span></a> </div>
								</div>
								<div class="col-12">
									<hr class="no_line" style="margin: 0 auto 50px auto" /> </div>
								<div class="col-12">
									<hr style="margin:0 auto 100px;background-color:#eed7b9" /> </div>
							</div>
						</div>
						<div class="col-md-4" data-col="one-third">
							<div class="row no-gutters">
								<div class="col-md-2">
									<div class="image_frame image_item no_link scale-with-grid aligncenter no_border">
										<div class="image_wrapper"><img class="scale-with-grid" src="content/dietshop/images/dietshop-home-icon1.webp" alt="dietshop-home-icon1" width="43" height="55" /> </div>
									</div>
								</div>
								<div class="col-md-10">
									<div class="column_attr clearfix mobile_align_center" style="padding:0 4%;">
										<p> <b>Sed do eiusmod tempor incididunt ut labore</b> </p>
									</div>
								</div>
							</div>
						</div>
						<div class="col-md-4" data-col="one-third">
							<div class="row no-gutters">
								<div class="col-md-2">
									<div class="image_frame image_item no_link scale-with-grid aligncenter no_border">
										<div class="image_wrapper"><img class="scale-with-grid" src="content/dietshop/images/dietshop-home-icon2.webp" alt="dietshop-home-icon2" width="55" height="55" /> </div>
									</div>
								</div>
								<div class="col-md-10">
									<div class="column_attr clearfix mobile_align_center" style="padding:0 4%;">
										<p> <b>Duis aute irure dolor in reprehen a voluptate</b> </p>
									</div>
								</div>
							</div>
						</div>
						<div class="col-md-4" data-col="one-third">
							<div class="row no-gutters">
								<div class="col-md-2">
									<div class="image_frame image_item no_link scale-with-grid aligncenter no_border">
										<div class="image_wrapper"><img class="scale-with-grid" src="content/dietshop/images/dietshop-home-icon3.webp" alt="dietshop-home-icon3" width="55" height="55" /> </div>
									</div>
								</div>
								<div class="col-md-10">
									<div class="column_attr clearfix mobile_align_center" style="padding:0 4%;">
										<p> <b>Lorem ipsum dolor sit amet, consectetur </b> </p>
									</div>
								</div>
							</div>
						</div>
						<div class="col-12">
							<hr class="no_line" style="margin:0 auto 20px"> </div>
						<div class="col-md-4" data-col="one-third">
							<div class="row no-gutters">
								<div class="col-md-2">
									<div class="image_frame image_item no_link scale-with-grid aligncenter no_border">
										<div class="image_wrapper"><img class="scale-with-grid" src="content/dietshop/images/dietshop-home-icon4.webp" alt="dietshop-home-icon4" width="55" height="55" /> </div>
									</div>
								</div>
								<div class="col-md-10">
									<div class="column_attr clearfix mobile_align_center" style="padding:0 4%;">
										<p> <b>Et dolore magna aliqua a enim ad minim veniam</b> </p>
									</div>
								</div>
							</div>
						</div>
						<div class="col-md-4" data-col="one-third">
							<div class="row no-gutters">
								<div class="col-md-2">
									<div class="image_frame image_item no_link scale-with-grid aligncenter no_border">
										<div class="image_wrapper"><img class="scale-with-grid" src="content/dietshop/images/dietshop-home-icon5.webp" alt="dietshop-home-icon5" width="55" height="55" /> </div>
									</div>
								</div>
								<div class="col-md-10">
									<div class="column_attr clearfix mobile_align_center" style="padding:0 4%;">
										<p> <b>Exercitation ullamco laboris nisi ut aliquip </b> </p>
									</div>
								</div>
							</div>
						</div>
						<div class="col-md-4" data-col="one-third">
							<div class="row no-gutters">
								<div class="col-md-2">
									<div class="image_frame image_item no_link scale-with-grid aligncenter no_border">
										<div class="image_wrapper"><img class="scale-with-grid" src="content/dietshop/images/dietshop-home-icon6.webp" alt="dietshop-home-icon6" width="55" height="55" /> </div>
									</div>
								</div>
								<div class="col-md-10">
									<div class="column_attr clearfix mobile_align_center" style="padding:0 4%;">
										<p> <b>Voluptate velit esse cillum dolore eu fugiat nulla</b> </p>
									</div>
								</div>
							</div>
						</div>
						<div class="col-12" data-col="one">
							<hr class="no_line" style="margin: 0 auto 80px auto" /> </div>
						<div class="col-12" data-col="one">
							<div class="row">
								<div class="col-md-2">
									<div class="placeholder"> &nbsp; </div>
								</div>
								<div class="col-md-9">
									<div class="column_attr clearfix align_center">
										<h2>Ingredients <img class="scale-with-grid" src="content/dietshop/images/dietshop-icon6.webp"/><img class="scale-with-grid" src="content/dietshop/images/dietshop-icon7.webp"/><img class="scale-with-grid" src="content/dietshop/images/dietshop-icon8.webp"/><img class="scale-with-grid" src="content/dietshop/images/dietshop-icon9.webp"/><img class="scale-with-grid" src="content/dietshop/images/dietshop-icon2.webp"/><img class="scale-with-grid" src="content/dietshop/images/dietshop-icon10.webp"/> that we use <span style="color: #6e2a36;">are always fresh and ready to make your perfect diet!</span></h2> </div>
								</div>
							</div>
						</div>
						<div class="col-12">
							<hr class="no_line" style="margin:0 auto 40px"> </div>
					</div>
				</div>
			</div>
		</div>
		<footer id="Footer" class="clearfix">
			<div class="container">
				<div class="row">
					<div class="col-12">
						<hr class="no_line" style="margin:0 auto 120px"> </div>
					<div class="col-md-3">
						<h4>Contact with us</h4>
						<p style="padding-right: 15px;"> Nullam viverra consectetuer quisque cursus et, porttitor risus. </p>
						<p> <a href="tel:+61 (0) 3 8376 6284" data-type="tel" data-id="tel:+61 (0) 3 8376 6284">+61 (0) 3 8376 6284</a>
							<br> <a href="#"><span>noreply@envato.com</span></a> </p>
						<hr class="no_line" style="margin:0 auto 20px">
						<h4>Localization</h4>
						<p> Envato
							<br> Level 13, 2 Elizabeth
							<br> Victoria 3000
							<br> Australia </p>
					</div>
					<div class="col-md-3">
						<h4>Useful links</h4>
						<ul>
							<li style="margin-bottom:25px;"> <i class="icon-dot" style="color:#75973a;"></i><a href="content/dietshop/contact.html">Contact us</a> </li>
							<li style="margin-bottom:25px;"> <i class="icon-dot" style="color:#75973a;"></i><a href="content/dietshop/about.html">Help &amp; About us</a> </li>
							<li style="margin-bottom:25px;"> <i class="icon-dot" style="color:#75973a;"></i><a href="#">Shipping &amp; Returns</a> </li>
							<li style="margin-bottom:25px;"> <i class="icon-dot" style="color:#75973a;"></i><a href="#">Refund Policy</a> </li>
							<li style="margin-bottom:25px;"> <i class="icon-dot" style="color:#75973a;"></i><a href="#">Press Room</a> </li>
							<li style="margin-bottom:25px;"> <i class="icon-dot" style="color:#75973a;"></i><a href="#">Privacy Policy</a> </li>
						</ul>
					</div>
					<div class="col-md-6">
						<h4>BE informed with our newsletter</h4>
						<div id="contactWrapper">
							<div id="contactform">
								<form method="post" id="reused_form">
									<div class="row">
										<div class="col-md-7">
											<input placeholder="Your e-mail" id="email" type="email" name="Email" required maxlength="50"> </div>
										<div class="col-md-5">
											<button class="button-primary" id="submit" type="submit">Subscribe</button>
										</div>
									</div>
								</form>
								<div id="success_message" style="display:none">
									<h3>Submitted the form successfully!</h3>
									<p>We will get back to you soon.</p>
								</div>
								<div id="error_message" style="width:100%; height:100%; display:none;">
									<h3>Error</h3> Sorry there was an error sending your form.</div>
							</div>
						</div>
						<hr class="no_line" style="margin:0 auto 20px">
						<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do </p>
						<hr class="no_line" style="margin:0 auto 70px">
						<p style="font-weight: 600;"> We accept:<img loading="lazy" style="margin: 0 25px; position: relative;" src="content/dietshop/images/dietshop-footer-icon1.webp" class="wp-image-32 scale-with-grid" width="304" height="25" /> </p>
					</div>
					<div class="col-12">
						<hr class="no_line" style="margin:0 auto 70px"> </div>
				</div>
			</div>
			<div class="footer_copy">
				<div class="container">
					<div class="column one"> <a id="back_to_top" class="footer_button" href="#"><i class="icon-up-open-big"></i></a>
						<div class="copyright"> &copy; 2021 - BeTheme. Muffin group - HTML by <a target="_blank" rel="nofollow" href="https://1.envato.market/9ZxXY">BeantownThemes</a> </div>
					</div>
				</div>
			</div>
		</footer>
	</div>
	<div id="body_overlay"></div>
	<div id="Side_slide" class="right light" data-width="250">
		<div class="close-wrapper"> <a href="#" class="close"><i class="icon-cancel-fine"></i></a> </div>
		<div class="menu_wrapper"></div>
	</div>
	<!-- JS -->
	<script src="js/jquery-3.6.0.min.js"></script>
	<script src="js/jquery-migrate-3.3.2.js"></script>
	<script src="js/mfn.menu.js"></script>
	<script src="js/jquery.plugins.js"></script>
	<script src="js/jquery.jplayer.min.js"></script>
	<script src="js/animations/animations.js"></script>
	<script src="js/translate3d.js"></script>
	<script src="js/scripts.js"></script>
	<script src="phpmailer/form.js"></script>
	<script src="plugins/rs-plugin-6.custom/js/revolution.tools.min.js"></script>
	<script src="plugins/rs-plugin-6.custom/js/rs6.min.js"></script>
	<script type="text/javascript">
	var revapi1, tpj;

	function revinit_revslider11() {
		jQuery(function() {
			tpj = jQuery;
			revapi1 = tpj("#rev_slider_1_1");
			if(revapi1 == undefined || revapi1.revolution == undefined) {
				revslider_showDoubleJqueryError("rev_slider_1_1");
			} else {
				revapi1.revolution({
					sliderLayout: "fullwidth",
					visibilityLevels: "1240,1240,778,778",
					gridwidth: "1400,1400,778,778",
					gridheight: "950,950,1100,1100",
					spinner: "spinner12",
					perspective: 600,
					perspectiveType: "global",
					spinnerclr: "#13d5ff",
					editorheight: "950,768,1100,720",
					responsiveLevels: "1240,1240,778,778",
					progressBar: {
						disableProgressBar: true
					},
					navigation: {
						onHoverStop: false
					},
					fallbacks: {
						allowHTML5AutoPlayOnAndroid: true
					},
				});
			}
		});
	} // End of RevInitScript
	var once_revslider11 = false;
	if(document.readyState === "loading") {
		document.addEventListener('readystatechange', function() {
			if((document.readyState === "interactive" || document.readyState === "complete") && !once_revslider11) {
				once_revslider11 = true;
				revinit_revslider11();
			}
		});
	} else {
		once_revslider11 = true;
		revinit_revslider11();
	}
	</script>
</body>

</html>