<?php require('views/guitarShopHeader.php'); ?>
<div id="content">
    <h2>Database Error</h2>
    <p>$error_message</p>
</div>
<?php
require('views/guitarShopFooter.php');
