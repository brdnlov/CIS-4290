<?php require('views/guitarShopHeader.php');?>
<main>
    <section>
        <h1>Come back soon!</h1>


    </section>
</main>
<?php require('views/guitarShopFooter.php');
