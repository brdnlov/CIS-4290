<?php require('views/guitarShopHeader.php'); ?>
<div id="content">
    <h2>Shopping Cart - under construction</h2>
</div>
<?php
require('views/guitarShopFooter.php');
